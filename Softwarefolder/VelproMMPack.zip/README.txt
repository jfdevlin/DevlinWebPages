VelProbePE_3_Betas

VelProbe_MM_3_Beta-b February, 2018
-Corrects a bug that arises when the 'jump' in background is bounded by points with identical responses

VelProbe_MM_3_Beta_a  October, 2017
-The version posted here (v. 3.1, beta-a, or VeloproMM October 15, 2017) performs the same tasks as the earlier versions, but is programmed with advanced userforms that simplify dataprocessing, including the addition of algorithms for the use of method of moments to estimate tracer velocity from breakthrough curves, and to perform the repair of baselines that suffer from 'jumps' or similar discontinuities due to electrical surges in power sources or by natural phenomena. 

VelProbePE_3_ Beta _g
- extensive additions of user friendly forms including central control panel
- optional signal inversion to handle saline tracers and DI water
- breakthrough curves now have table of calculated breakthrough with formulas that can be manually manipulated to aid optimization
- formulas now present in PVP calculations on "Results" sheets to aid troubleshooting
- reset button added to control panel so baseline manipulations can be easily removed and the curves reanalyzed from scratch
- overview sheet now created with graphical representations of all half bridge data for comparision and distinction of noise from peaks
- button added to "datalogger file" tab to reinitiate analysis; but to create "Overview" sheet also present there
- button added to permit 16 HB channel files to be trimmed to the desired number of HBs
- option added to enter default transport parameters and distances to detectors when breakthrough curve analysis begins
- dialog boxes reduced in size and moved to upper left of screen to improve visibility of spreadsheets

Beta-f version:
- programed refit userform to update default transport parameters with each refit

Beta-e version:
May 15, 2013 
- fixed a bug in the 'RESET' option on Userform7
- fixed a bug in graph regeneration during fitting - observed data remain points now
- fixed sheet number table in Datalogger file - now updates properly when workbook is trimmed
May 16, 2013
- overview graphs not aligning correctly - modified code to correct



VelProbePE_2.2.2

Since VelProbePE_2.2.1
- bug fixed in which gamma angles (from injection screen to detectors) were calculated based on incorrectly read perimeter distances  May 8, 2011.

VelProbePE_3.1 beta-C

Since VelProbePe_2.2.2
-Improvement to Baseline handling.  With release 3.1 a baseline repair option was added to handle cases in which electronic 'jumps' instantaneously move the baseline.  The repair option removes the 'jump', re-establishing a continuous baseline

-In some cases the 'jump' is not truly instantaneous and several points are collected, effectively establishing an anomalous, short duration peak.  Another option was added to the baseline dialogue box to permit a section of the BTC that includes the short duration peak to be cut from the record.  This permits the optimization and momments cacluations to proceed without the anomalous point affected the estimated velocity.

 